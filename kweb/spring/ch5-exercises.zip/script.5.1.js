const setRandomBgColor = () => {

};
