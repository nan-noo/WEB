const displayTimes = () => {

};
